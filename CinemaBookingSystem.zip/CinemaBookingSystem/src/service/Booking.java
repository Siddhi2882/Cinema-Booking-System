package service;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import entity.Movie;
import entity.Seat;
import entity.ShowTime;
import exception.SeatNotAvailable;

public class Booking {
	ShowTime showtime;
	ArrayList<ShowTime> booking;
	private String bookingId;
	String LogFile = "C:\\Users\\CDAC\\Desktop\\AkshayLab\\MovieProject.txt";

	public Booking() {
	
		booking = new ArrayList<>();
	}
	
	 void logshowDetails(String message) throws IOException {
	        BufferedWriter writer = new BufferedWriter(new FileWriter(LogFile));
	        writer.write(message);
	        writer.newLine();
	        writer.close();
	    }

	public ArrayList<ShowTime> bookMovieseat(String movieId, String seatId) throws Exception{
		Movie m = new Movie(movieId);
		Seat s = new Seat(seatId);
		ShowTime ss = new ShowTime();
		String showt = ss.getShowTime();
		if (s.isAvaliable() == true ) {
			ShowTime ss1 = new ShowTime(movieId, seatId, showt);
			booking.add(ss1);
			String msg = "Movie booking details"
					+"\nMovieId :"+m.getMovieId()
					+"\nSeatId: "+s.getSeatId()
					+"\nShowTime: "+ss.getShowTime();
			logshowDetails(msg);
		} else {
			throw new SeatNotAvailable("SeatNotAvailable:Seat not available");
		}
		return booking;
	}
}
