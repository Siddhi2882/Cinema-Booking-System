package exception;

public class SeatNotAvailable extends Exception {
public SeatNotAvailable(String msg) {
	super(msg);
}
}
