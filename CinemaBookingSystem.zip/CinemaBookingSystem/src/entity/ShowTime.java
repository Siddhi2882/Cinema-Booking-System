package entity;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class ShowTime {
	private String showTime;
	static int sid = 12;
	HashMap<String, Movie> movies;
	HashMap<Integer, Seat> seats;
	String movieId;
	String seat;
	// Movie m = new Movie();

	public ShowTime() {
		this.showTime = "" + sid;
		movies = new HashMap<String, Movie>();
		seats = new HashMap<Integer, Seat>();
	}

	public ShowTime(String showTime, String movieId, String seat) {
		super();
		this.showTime = showTime;
		this.movieId = movieId;
		this.seat = seat;
	}

	public String getShowTime() {
		return showTime;
	}
	
	public Movie getMovie(String movieId) {
		return movies.get(movieId);

	}
	public Seat getSeat(String movieId) {
		return seats.get(movieId);

	}

	public void setShowTime(String showTime) {
		this.showTime = showTime;
	}

	public void addMovies(Movie movie) {
		movies.put(movie.getMovieId(), movie);
		System.out.println("Movie added");
	}

	public void removeMovies(String movieid) {
		if (seats.containsKey(movieid)) {
			seats.remove(movieid);
		}
	}

	public void bookSeat(int n, Seat s) {
		// Seat s = new Seat();
		if (s.isAvaliable() == true) {
			for (int i = 1; i <= n; i++) {
				seats.put(n, s);
			}
		}
	}

	public void showAllMovie() {

		for (Movie m : movies.values()) {
			System.out.println("Movie title: " + m.getTitle() + "\nMovieId: " + m.getMovieId());
		}
	}

	public void showSeats() {
		for (Movie m : movies.values()) {
			System.out.println("Movie title: " + m.getTitle() + "\nMovieId: " + m.getMovieId());
		}
		// System.out.println("Number of tickets: 3");
		for (Seat s : seats.values()) {
			System.out.println("Number of tickets: " + seats.entrySet() + "Seats: " + s.getSeatId());

		}
//		for(Map.Entry<Integer,String> s = seats.entrySet()) {
//			
//		}
	}

}
