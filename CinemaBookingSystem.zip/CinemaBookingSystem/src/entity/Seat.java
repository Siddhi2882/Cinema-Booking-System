package entity;

public class Seat {
private String seatId;
static int sId=0;
boolean isAvaliable;
public Seat() {
	// TODO Auto-generated constructor stub
}
public Seat(String seatId) {
	super();
	this.seatId = "SID"+ ++sId;
	this.isAvaliable = true;
}
public String getSeatId() {
	return seatId;
}
public void setSeatId(String seatId) {
	this.seatId = seatId;
}
public boolean isAvaliable() {
	return isAvaliable;
}
public void setAvaliable(boolean isAvaliable) {
	this.isAvaliable = isAvaliable;
}


}
