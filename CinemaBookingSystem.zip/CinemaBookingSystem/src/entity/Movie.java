package entity;

public class Movie {
private String movieId;
private String title;
static int id = 1000;

public Movie( String title) {
	super();
	this.movieId = "MID"+ ++id;
	this.title = title;
}
public String getMovieId() {
	return movieId;
}
public void setMovieId(String movieId) {
	this.movieId = movieId;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public static int getId() {
	return id;
}
public static void setId(int id) {
	Movie.id = id;
}

}
