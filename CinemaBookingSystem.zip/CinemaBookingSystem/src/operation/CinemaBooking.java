package operation;

import java.util.Scanner;

import entity.Movie;
import entity.Seat;
import entity.ShowTime;
import exception.SeatNotAvailable;
import service.Booking;

public class CinemaBooking {

	public static void main(String[] args) throws Exception {
		ShowTime show = new ShowTime();
		Scanner sc = new Scanner(System.in);
		int ch;
		
		do {
			System.out.println("1.Add Movie");
			System.out.println("2.remove Movie");
			System.out.println("3.show all movies");
			System.out.println("4 Book Multiple tickets");
			System.out.println("5 Show all tickets");
			System.out.println("6.BookMovie");
			System.out.println("0.Exit");
			System.out.println("Enter your choice");
			ch=sc.nextInt();
			switch(ch) {
			case 1:{
				System.out.println("Enter movie name");
				String name= sc.next();
				Movie m = new Movie(name);
				show.addMovies(m);
				break;
			}
			case 2:{
				System.out.println("Enter movie id to remove");
				String id =sc.next();
				show.removeMovies(id);
				break;
				
			}
			case 3:
			{
				System.out.println("All details of movies");
				show.showAllMovie();
				break;
			}
			case 4:
			{
				System.out.println("Enter numer of tickets");
				int n = sc.nextInt();
				System.out.println("Enter SeatId");
				String Sid=sc.next();
				Seat s = new Seat(Sid);
				show.bookSeat(n,s);
				break;
			}
			case 5:
			
				{
					System.out.println("All details of seat");
					show.showSeats();
					break;
				}
			
			case 6:{
				try {
				System.out.println("Enter SeatId");
				String Sid=sc.next();
				System.out.println("Enter MovieId");
				String Mid=sc.next();
				Booking b = new Booking();
				b.bookMovieseat(Mid, Sid);
				break;
				}catch(SeatNotAvailable e) {
					System.out.println(e.getMessage());
				}
				
				
			}
			
			case 0:{
				System.out.println("Thank for ");
				System.exit(0);
			}
		
		}
			
		
	}while(ch!=0);

}
}
